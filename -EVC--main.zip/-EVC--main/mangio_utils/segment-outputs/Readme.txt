This folder (segment-outputs) is where all segment outputs created from the inference-batcher.py
are stored temporarily.